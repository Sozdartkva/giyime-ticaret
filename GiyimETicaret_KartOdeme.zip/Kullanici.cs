using System;
using System.Collections.Generic;

public class Kullanici
{
    public string KullaniciAdi { get; set; }
    public string Sifre { get; set; }
    public bool AdminMi { get; set; }
    public List<Urun> Sepet { get; set; }

    public Kullanici(string kullaniciAdi, string sifre, bool adminMi = false)
    {
        KullaniciAdi = kullaniciAdi;
        Sifre = sifre;
        AdminMi = adminMi;
        Sepet = new List<Urun>();
    }

    public void SepeteEkle(Urun urun)
    {
        Sepet.Add(urun);
    }

    public void SepetiGoster()
    {
        Console.WriteLine("\n--- Sepetiniz ---");
        if (Sepet.Count == 0)
        {
            Console.WriteLine("Sepetiniz boş.");
            return;
        }

        foreach (var urun in Sepet)
        {
            Console.WriteLine(urun);
        }

        decimal toplam = 0;
        foreach (var urun in Sepet)
        {
            toplam += urun.Fiyat;
        }
        Console.WriteLine($"Toplam Tutar: {toplam} ₺");
    }

    public void SiparisiTamamla()
    {
        if (Sepet.Count == 0)
        {
            Console.WriteLine("Sepetiniz boş. Sipariş verilemez.");
            return;
        }

        Console.WriteLine("\n--- Ödeme Bilgileri ---");
        Console.Write("Kart Numarası (16 haneli): ");
        string kartNo = Console.ReadLine();
        Console.Write("Son Kullanma Tarihi (AA/YY): ");
        string sonKullanma = Console.ReadLine();
        Console.Write("CVV (3 haneli): ");
        string cvv = Console.ReadLine();

        if (kartNo.Length == 16 && cvv.Length == 3 && sonKullanma.Length == 5 && sonKullanma.Contains("/"))
        {
            Console.WriteLine("\nÖdeme işlemi başarılı!");
            Console.WriteLine("Siparişiniz oluşturuldu. Sipariş özeti:");
            SepetiGoster();
            Sepet.Clear();
        }
        else
        {
            Console.WriteLine("Geçersiz kart bilgileri. Sipariş iptal edildi.");
        }
    }
}